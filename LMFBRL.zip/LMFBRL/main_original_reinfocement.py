#!/usr/bin/env python3
import random

from .compression_types import CompressionTypeBase
import numpy as np


class Algorithm():
    """
    This class implements model compression using LC framework. See [1] for more details on the algorithm.

    To compress a model, user needs to construct lc.Algorithm object and provide:
        1) a model to be compressed,
        2) the associated compression tasks,
        3) an implementation of the L-step, i.e. the function to optimize the loss + a penalty
        4) a schedule of μ values.

    To start the compression .run() method should be invoked. # 被调用

    References:
    1. Miguel Á. Carreira-Perpiñán
       Model compression as constrained optimization, with application to neural nets.Part I: general framework.
       https://arxiv.org/abs/1707.01209

    """
    def __init__(self, model, compression_tasks, mu_schedule, l_step_optimization, evaluation_func, c_step_reps=10):
        """
        Constructs lc.Algorithm object
        :param model: model to compress
        :param compression_tasks: a dictionary mapping lc.Parameter => (compression view, compression type, task_name),
        :param mu_schedule: a list of μ values (doubles)
        :param l_step_optimization:
        :param evaluation_func:
        :param c_step_reps: How many times the alternation between c-steps will happen in additive compression regime.
            Has no effect otherwise.
        """

        super(Algorithm, self).__init__()
        self.model = model
        self.mu = None
        self.mu_schedule = mu_schedule
        self.lc_parameters = compression_tasks.keys()
        self.c_step_reps = c_step_reps

        # user provides a constructor for a view, but it must be converted to an actual view
        # which happens here:
        for param in compression_tasks.keys():
            one_or_multiple_tasks = compression_tasks[param]

            if isinstance(one_or_multiple_tasks, tuple):
                # single compression per task
                (compression_view_constructor, compression, compression_fm, task_name) = compression_tasks[param]
                if isinstance(compression, CompressionTypeBase):
                    compression_tasks[param] = (compression_view_constructor(param.w_view.original_form), compression, compression_fm, task_name)
                else:
                    raise Exception("The given compression is not an instance of CompressionTypeBase")
            elif isinstance(one_or_multiple_tasks, list) and len(one_or_multiple_tasks) == 1:
                (compression_view_constructor, compression, compression_fm, task_name) = compression_tasks[param][0]
                if isinstance(compression, CompressionTypeBase):
                    compression_tasks[param] = (compression_view_constructor(param.w_view.original_form), compression, compression_fm, task_name)
                else:
                    raise Exception("The given compression is not an instance of CompressionTypeBase")
            elif isinstance(one_or_multiple_tasks, list):
                # additive combinations
                for param in compression_tasks.keys():
                    list_ = []
                    for (compression_view_constructor, compression, compression_fm,  task_name) in compression_tasks[param]:
                        list_.append((compression_view_constructor(param.w_view.original_form), compression, compression_fm, task_name))
                        compression.current_sol = 0
                    compression_tasks[param] = list_
            else:
                raise Exception("The given compression tasks are not supported or contain an error:"
                                "Given compression is not a child of CompressionTypeBase nor a list of CompressionTypeBase-s")

        self.compression_tasks = compression_tasks
        # self.additive_compression_tasks = additive_compression_tasks
        self.l_step_optimization = l_step_optimization
        self.evaluation_func = evaluation_func
        self.retrieve()

    def lc_penalty(self):
        """
        Computes total penalty among all lc.Parameters for this compression run.
        """
        loss_ = 0.0
        for lc_parameter in self.lc_parameters:
            loss_ += self.mu*0.5*lc_parameter.lc_penalty()

        return loss_

    def release(self):
        for param in self.lc_parameters:
            param.release()

    def retrieve(self):
        for param in self.lc_parameters:
            param.retrieve()

    # 在这里，作者将β跟λ相等了。这里是对β ← β − μ(W − Θ)的处理
    def multipliers_step(self):
        """
        Updates Lagrange multipliers estimates in one step procedure.
        """
        for param in self.lc_parameters:
            param.lambda_ -= self.mu * (param.w - param.delta_theta)

    def compression_eval(self):
        """
        Sets w=Δ(ϴ), i.e. making sure that model weights are coming from compression.
        :return:
        """
        for param in self.lc_parameters:
            param.eval()

    def compression_train(self):
        for param in self.lc_parameters:
            param.train()

    def evaluate(self):
        # first make regular evaluation of LC objective: loss + lc_penalty
        # self.evaluation_func()
        # then compressed evaluation of objective: loss
        self.compression_eval()
        self.evaluation_func(self.model)
        self.compression_train()

    def c_step(self, step_number):
        """
        This methods performs actual C-steps on compression tasks. For every task given, it runs extracts model
        parameters associated with the task, reshapes them according to compression view and compresses them. The result
        of compression will be put into param.delta_theta
        """
        # compression_tasks[Param(w, device)] = (AsIs, LowRank(target_rank=r, conv_scheme=None), f'task_{i}')
        task = []
        choose_method_select_rank = []
        param_ = []
        task_details_ = []
        compression_tasks_ = {}
        epsilon_ = 0.3
        e_i = 0
        layer = len(self.compression_tasks)

        for param, task_details in self.compression_tasks.items():
            param_.append(param)
            task_details_.append(task_details)
        len_param = len(param_)
        for i in range(len_param):
            compression_tasks_[param_[len_param-i-1]] = task_details_[len_param-i-1]

        if layer <= 10:
            for param, task_details in compression_tasks_.items():
                if isinstance(task_details, tuple):
                    view, compression, compression_fm, _name = task_details # view为权值参数的形状，compresssion为压缩的类型，_name为任务的名称
                    # The c-steps for regular compression tasks (one compression per task). We need to solve
                    #   min ‖w-Δ(Θ)-λ/μ‖²
                    # which is given by C-step of Δ for (w-λ/μ).

                    # offset weight vector: w_lambda_mu =  w - lambda/mu => (w-λ/μ)
                    w_lambda_mu = param.w - (0 if self.mu == 0 else (1 / self.mu) * param.lambda_)
                    # 这里的mu赋值给了compression-RankSelection中的self.mu参数

                    compression.mu = self.mu
                    compression_fm.mu = self.mu
                    compression.step_number = step_number
                    compression_fm.step_number = step_number

                    w_lambda_mu_compression_view = param.vector_to_compression_view(w_lambda_mu, view)

                    delta_theta_compression_view = compression.compress(w_lambda_mu_compression_view)
                    delta_theta_compression_view_fm = compression_fm.compress(w_lambda_mu_compression_view)
                    # 各种分解方式分解后的参数数目
                    space_cost_ = compression.loss_svd()
                    space_cost_fm = compression_fm.loss_mf()
                    select_rank_svd = compression.info[step_number]['selected_rank']
                    select_rank_fm = compression_fm.info[step_number]['selected_rank']
                    # space_cost_ = np.float(space_cost_)
                    # space_cost_fm = np.float(space_cost_fm)
                    # updated the current delta_theta, i.e. Δ(Θ)

                    print("SVD compression eval:")
                    param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view, view)
                    param.eval()
                    loss_ = self.evaluation_func(self.model)
                    param.train()
                    print("FM compression eval:")
                    param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view_fm, view)
                    param.eval()
                    loss_fm = self.evaluation_func(self.model)
                    param.train()

                    # cost_svd = space_cost_ + loss_
                    # cost_fm = space_cost_fm + loss_fm
                    cost_svd = 10 * space_cost_ + loss_['nested_test_loss']
                    cost_fm = 10 * space_cost_fm + loss_fm['nested_test_loss']
                    print("SVD::cost:{},error:{}".format(space_cost_, loss_['nested_test_loss']))
                    print("MF::cost:{},error:{}".format(space_cost_fm, loss_fm['nested_test_loss']))
                    print("For {} layer the svd cost:{}, the fm cost:{}".format(int(_name[-1]) + 1, cost_svd, cost_fm))
                    if cost_svd <= cost_fm:
                        param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view, view)
                        task.append("SVD")
                        choose_method_select_rank.append(select_rank_svd)
                        # print("The {} layer compression choose SVD!".format(_name[-1]))
                    else:
                        param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view_fm, view)
                        task.append("FM")
                        choose_method_select_rank.append(select_rank_fm)
                        # print("The {} layer compression choose FM!".format(_name[-1]))

        else:
            for param, task_details in compression_tasks_.items():
                epsilon = epsilon_ * (0.95 ** e_i)
                omiga = np.random.rand()
                print("******************omiga:", omiga)
                print("******************eps:",epsilon)
                if isinstance(task_details, tuple):
                    view, compression, compression_fm, _name = task_details # view为权值参数的形状，compresssion为压缩的类型，_name为任务的名称
                    # The c-steps for regular compression tasks (one compression per task). We need to solve
                    #   min ‖w-Δ(Θ)-λ/μ‖²
                    # which is given by C-step of Δ for (w-λ/μ).

                    # offset weight vector: w_lambda_mu =  w - lambda/mu => (w-λ/μ)
                    w_lambda_mu = param.w - (0 if self.mu == 0 else (1 / self.mu) * param.lambda_)

                    if omiga <= epsilon:
                        choice_num = random.choice([1,2])
                        # print("+++++++++++choice_num",choice_num)
                        if choice_num == 1:
                            # print("__________SVD1")
                            compression.mu = self.mu
                            compression.step_number = step_number
                            w_lambda_mu_compression_view = param.vector_to_compression_view(w_lambda_mu, view)
                            delta_theta_compression_view = compression.compress(w_lambda_mu_compression_view)
                            select_rank_svd = compression.info[step_number]['selected_rank']
                            # updated the current delta_theta, i.e. Δ(Θ)
                            param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view, view)
                            task.append("SVD")
                            choose_method_select_rank.append(select_rank_svd)
                            print("For {} layer choose SVD,select rank:{}".format(int(_name[-1]) + 1, select_rank_svd))
                        elif choice_num == 2:
                            # print("__________MF2")
                            compression_fm.mu = self.mu
                            compression_fm.step_number = step_number
                            w_lambda_mu_compression_view = param.vector_to_compression_view(w_lambda_mu, view)
                            delta_theta_compression_view = compression_fm.compress(w_lambda_mu_compression_view)
                            select_rank_fm = compression_fm.info[step_number]['selected_rank']
                            # updated the current delta_theta, i.e. Δ(Θ)
                            param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view, view)
                            task.append("FM")
                            choose_method_select_rank.append(select_rank_fm)
                            print("For {} layer choose MF,select rank:{}".format(int(_name[-1]) + 1, select_rank_fm))
                    else:

                        # 这里的mu赋值给了compression-RankSelection中的self.mu参数
                        compression.mu = self.mu
                        compression_fm.mu = self.mu
                        compression.step_number = step_number
                        compression_fm.step_number = step_number

                        w_lambda_mu_compression_view = param.vector_to_compression_view(w_lambda_mu, view)

                        delta_theta_compression_view = compression.compress(w_lambda_mu_compression_view)
                        delta_theta_compression_view_fm = compression_fm.compress(w_lambda_mu_compression_view)
                        # 各种分解方式分解后的参数数目
                        space_cost_ = compression.loss_svd()
                        space_cost_fm = compression_fm.loss_mf()
                        select_rank_svd = compression.info[step_number]['selected_rank']
                        select_rank_fm = compression_fm.info[step_number]['selected_rank']
                        # space_cost_ = np.float(space_cost_)
                        # space_cost_fm = np.float(space_cost_fm)
                        # updated the current delta_theta, i.e. Δ(Θ)

                        print("SVD compression eval:")
                        param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view, view)
                        param.eval()
                        loss_ = self.evaluation_func(self.model)
                        param.train()
                        print("FM compression eval:")
                        param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view_fm, view)
                        param.eval()
                        loss_fm = self.evaluation_func(self.model)
                        param.train()

                        # cost_svd = space_cost_ + loss_
                        # cost_fm = space_cost_fm + loss_fm
                        cost_svd = space_cost_ + loss_['nested_test_loss']
                        cost_fm = space_cost_fm + loss_fm['nested_test_loss']
                        print("SVD::cost:{},error:{}".format(space_cost_, loss_['nested_test_loss']))
                        print("MF::cost:{},error:{}".format(space_cost_fm, loss_fm['nested_test_loss']))
                        print("For {} layer the svd cost:{}, the fm cost:{}".format(int(_name[-1]) + 1, cost_svd, cost_fm))
                        if cost_svd <= cost_fm:
                            param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view, view)
                            task.append("SVD")
                            choose_method_select_rank.append(select_rank_svd)
                            # print("The {} layer compression choose SVD!".format(_name[-1]))
                        else:
                            param.delta_theta = param.compression_view_to_vector(delta_theta_compression_view_fm, view)
                            task.append("FM")
                            choose_method_select_rank.append(select_rank_fm)
                            # print("The {} layer compression choose FM!".format(_name[-1]))

        for i, param in enumerate(self.lc_parameters):
            print("The {} layer compression choose {}!".format(len_param - i, task[i]))
        return task,choose_method_select_rank



    def l_step(self, step):
        """
        This method sets a new target for the LC penalty function and invokes user supplied L_step_optimization function.
        Since L-step optimization interacts with outside DL frameworks, everything should be packed so these frameworks
        can work with new input properly.
        """
        # before releasing we combine Lagrange multipliers with quadratic penalty values to update target for penalty
        # aka offset compressed weight vector, which will be target for the penalty
        for param in self.lc_parameters:
            param.target = param.delta_theta + (0 if self.mu == 0 else (1 / self.mu) * param.lambda_)

        self.release()
        self.l_step_optimization(self.model, self.lc_penalty, step)
        self.retrieve()

    def count_params(self):
        """
        Computes the number of current compressed parameters.
        """
        total_params = 0
        for param, task_details in self.compression_tasks.items():
            if isinstance(task_details, tuple):
                _, compression, _ = task_details
                total_params += compression.count_params()

            elif isinstance(task_details, list):
                # Additive compressions regime
                for (_, compression, _) in task_details:
                    # we compute \sum_{i≠k}Δᵢ(Θᵢ) first
                    total_params += compression.count_params()

        return total_params

    def count_param_bits(self):
        """
        Computes the number of bits required to store the current compressed version of the parameters.
        """
        total_param_bits = 0
        for param, task_details in self.compression_tasks.items():
            if isinstance(task_details, tuple):
                _, compression, _ = task_details
                total_param_bits += compression.count_param_bits()

            elif isinstance(task_details, list):
                # Additive compressions regime
                for (_, compression, _) in task_details:
                    # we compute \sum_{i≠k}Δᵢ(Θᵢ) first
                    total_param_bits += compression.count_param_bits()

        return total_param_bits

    def run(self):
        """
        This runs the LC algorithm proper.
        """
        # set mu=0 to perform direct compression
        self.mu = 0
        self.c_step(step_number=0)
        print("Direct compression has been performed.")

        for param in self.lc_parameters:
            param.lambda_ *= 0
            # this will effectively set Lagrange multipliers to 0

        self.evaluate() # evaluates train/test acc-s
        test = [1e-3 * (1.1 ** n) for n in range(20)]
        for step_number, mu in enumerate(test): # enumerate(self.mu_schedule)
            self.mu = mu
            print(self.mu)
            self.l_step(step_number)
            print(f"L-step #{step_number} has finished.")
            self.c_step(step_number)
            print(f"C-step #{step_number} has finished.")
            self.multipliers_step()
            print("Lagrange multipliers have been updated.")
            self.evaluate()
