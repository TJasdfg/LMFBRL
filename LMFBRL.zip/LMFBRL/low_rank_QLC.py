#!/usr/bin/env python3
from .base_types import CompressionTypeBase
import numpy as np
from scipy.linalg import svd
from torch.jit import Error

"""
References:
[1] Yerlan Idelbayev and Miguel Á. Carreira-Perpiñán
    Low-rank Compression of Neural Nets: Learning the Rank of Each Layer, CVPR2020,
    http://graduatestudent.ucmerced.edu/yidelbayev/papers/cvpr20/cvpr20a.pdf
"""

def tensor_to_matrix(tensor, conv_scheme):
    """
    Reshape a tensor into a matrix according to a scheme.
    :param tensor:
    :param conv_scheme: currently we support two scheme: scheme-1 and scheme-2
    :return: a matrix containing tensor's elements
    """
    matrix = tensor
    init_shape = tensor.shape
    if tensor.ndim == 4:
        if conv_scheme == 'scheme_1':
            matrix = tensor.reshape(init_shape[0], -1)
        elif conv_scheme == 'scheme_2':
            [n, m, d1, d2] = tensor.shape
            swapped = tensor.swapaxes(1, 2)
            matrix = swapped.reshape([n * d1, m * d2])
        else:
            raise NotImplementedError('This type of shape parametrization is not implemented yet.')

    if not np.allclose(tensor, matrix_to_tensor(matrix, init_shape, conv_scheme)):
        raise NotImplementedError("The Tensor->Matrix->Tensor conversion is not correctly implemented.")
    return matrix


def matrix_to_tensor(matrix, init_shape, conv_scheme):
    """
    Reshapes previously reshaped matrix into the original tensor.
    :param matrix: matrix to be converted back
    :param init_shape: the initial shape of the tensor
    :param conv_scheme: the convolutional scheme used for reshape
    :return:
    """
    tensor = matrix
    if len(init_shape) == 4:
        if conv_scheme == "scheme_1":
            tensor = matrix.reshape(init_shape)
        elif conv_scheme == 'scheme_2':
            [n, m, d1, d2] = init_shape
            tensor = matrix.reshape([n, d1, m, d2]).swapaxes(1, 2)
        else:
            raise NotImplementedError('This type of shape parametrization is not implemented yet.')
    return tensor


class LowRank(CompressionTypeBase):
    def __init__(self, target_rank, conv_scheme=None, precision='float'):
        """
        The low-rank compression of the matrix into given low-rank. If tensor is given, then it should be reshaped into
        a matrix according to a conv_scheme: either of scheme_1 or scheme_2.

        :param target_rank: the target rank of compressed weights
        :param conv_scheme: if tensor is given, how it should be reshaped into matrix
        :param precision: should be store low-rank U,V with different precision (32 or 16 bits)
        """
#         print("are we here?")
        super(LowRank, self).__init__()
        self.target_rank = target_rank
        self.conv_scheme = conv_scheme
        self.precision = (32 if precision == 'float' else precision)

    def perform_svd(self, matrix):
        u, s, v = svd(matrix, full_matrices=False)
        return u,s,v

    def compress(self, data):
        print("we are here")
        matrix = None
        init_shape = data.shape
        if data.ndim == 2:
            matrix = data
        elif data.ndim == 4:
            matrix = tensor_to_matrix(data, self.conv_scheme)

        u, s, v = self.perform_svd(matrix)
        r = self.target_rank
        print("target_rank", self.target_rank)
        if r < np.min(matrix.shape):
            diag = np.diag(s[:r] ** 0.5)
            U = u[:, :r] @ diag
            V = diag @ v[:r, :]

            if self.precision == 16:
                print("Storing U,V matrices as 16bit IEEE floating point matrices.")
                U = U.astype(np.float16)
                V = V.astype(np.float16)

            low_rank_matrix = U @ V
            self.info[self.step_number] = [U, V]

            step_info = {"selected_rank": None, "singular_values": s }
            self.info[self.step_number] = step_info
            self._state = {"U": U, "V": V, "selected_rank": None, "init_shape": init_shape}

            print("Low-rank compression is finished")
            if len(init_shape) == 2:
                return low_rank_matrix
            elif len(init_shape) == 4:
                return matrix_to_tensor(low_rank_matrix, init_shape, self.conv_scheme)
        
        

    def load_state_dict(self, state_dict):
        self._state = state_dict

    def uncompress_state(self):
        U = self.state_dict['U']
        V = self.state_dict['V']
        if len(self.state_dict["init_shape"]) == 2:
            return U@V
        elif len(self.state_dict["init_shape"]) == 4:
            return matrix_to_tensor(U@V, self.state_dict["init_shape"], self.conv_scheme)

    def count_params(self):
        if "U" in self._state:
            return self._state['U'].size + self._state['V'].size + len(self._state['S'])
        else:
            raise Error("Cannot count the number of compressed params: no compression was performed")

    def count_param_bits(self):
        if "U" in self._state:
            return (self._state['U'].size + self._state['V'].size + len(self._state['S']))*32
        else:
            raise Error("Cannot count the number of compressed params: no compression was performed")


class RankSelection(LowRank):
    def __init__(self, conv_scheme, alpha, criterion, normalize, module):
        """
        This is the C step corresponding to optimization of:
            min_{U,V,r} ‖w-UVᵀ‖² + 𝛼 C(r)  s.t.  rank(w) <= r
        Which allows to automatically learn both rank and weights for low-rank compression of a neural network
        according to model selection criterion C(r): storage compression or FLOPs compression.

        See [1] for full details.

        :param conv_scheme: if compressed weights are in tensor form, then we reshape them according to a particular
            scheme: "scheme_1" or "scheme_2". If weights are in matrix form, this parameter is ignored.
        :param alpha: the trade-off parameter controlling the amount of compression, higher the alpha, higher the
            the compression. In the paper [1] we refer to it as lambda. Also, in the paper, the values of lambda is
            given wrt millions of parameters or flops, thus rescaled by 10^6. However in code, we don't use rescaled
            lambda, thus call it alpha. For example, if in the paper we give lambda=10^{-4}, you need to use
            alpha=10^{-10}.
        :param criterion: the selection criterion, either "storage" or "flopgs".
        :param normalize: whether we normalize the C-step loss by 1/‖w‖² or not. We find it useful for deep nets.
        :param module: the PyTorch module (layer) storing the weights, used to obtain the flops information.
        """
        super(RankSelection, self).__init__(None, conv_scheme)
        self.alpha = alpha
        self.module = module
        self.criterion = criterion
        self.selected_rank = 0
        self.normalize_matrix = normalize
        self.sigma = 1
        self.Cost_all = 0
        self.num_comp = 0

    def compress(self, data):
        init_shape = data.shape
        if data.ndim == 2:
            matrix = data
        elif data.ndim == 4:
            matrix = tensor_to_matrix(data, self.conv_scheme)

        u, s, v = self.perform_svd(matrix)
        m, n = matrix.shape
        self.matrix_num = m * n
        num_com = 0
        # print(matrix)
        # print('svd factorization is : ', s)
        max_rank = min(matrix.shape)
        selected_rank = 0
        best = float('Inf')
        rank_i_diff_frb_norm_sq = (s[::-1] ** 2).cumsum()[::-1] # 计算各级r的奇异值Σσ之和
        rank_i_frb_norm_sq = (s[:] ** 2).cumsum()
        # print(rank_i_diff_frb_norm_sq)

        norm_sq = 1.0
        mult = 1 if self.criterion == 'storage' else self.module.multiplier

        def cost(r):
            return r*(m+n+1)*mult

        if self.normalize_matrix:
            frob_norm_sq = rank_i_diff_frb_norm_sq[0]
            norm_sq = frob_norm_sq

        suggested_mu = 2 * self.alpha * (m + n) * mult / (s[0] ** 2 / norm_sq)
        # print(f'With current α = {self.alpha:.2e}, μ should be at least {suggested_mu:.2e}')

        for r in range(0, max_rank + 1):
            value_s = ((self.mu / 2) * rank_i_diff_frb_norm_sq[r]*(1/norm_sq) if r < max_rank else 0)
            value_r = self.alpha * cost(r) * 0.1
            value = value_r + value_s
            num_com = cost(r)
            cost_all = self.sigma * (cost(r) / self.matrix_num) + value_s * 0# * (1 / self.alpha)
                # self.alpha * cost(r) \
                #     + ((self.mu / 2) * rank_i_diff_frb_norm_sq[r]*(1/norm_sq) if r < max_rank else 0)
            # if r < max_rank:
            #     print('**s:{}, all:{}, val:{}:'.format(rank_i_diff_frb_norm_sq[r], 1/norm_sq, rank_i_diff_frb_norm_sq[r]*(1/norm_sq)))
            # print('Now r:{}, parameter:{}, r_cost:{}, s_cost:{}, alpha:{}'.format(r, cost(r), value_r, value_s, self.alpha))
            # print('the best value is:{}, now value is:{}, mu value:{}, select_rank:{}'.format(best, value, self.mu, selected_rank))
            # print('normal:{}, nor_val:{}'.format(self.normalize_matrix, norm_sq))
            # equivalent to =>
            # + self.mu/2*np.sum((values_to_compress-new_weights)**2)

            if value < best:
                selected_rank = r
                best = value
                self.Cost_all = cost_all
                self.num_comp = num_com
                # print('************')
                # print('now best value update:{}, best-rank:{}'.format(best, selected_rank))
                # print('************')

        diag = np.diag((s[:selected_rank]) ** 0.5) # 将一维数组s转化为方阵k×k
        U = u[:, :selected_rank] @ diag
        V = diag @ v[:selected_rank, :]
        low_rank_matrix = U @ V

        if selected_rank <= max_rank:
            frob_norm_diff = (rank_i_diff_frb_norm_sq[selected_rank]/norm_sq if selected_rank < max_rank else 0)
        else:
            frob_norm_diff = 0

        self.selected_rank = selected_rank
        S = s[:selected_rank]
        step_info = {
            "selected_rank": selected_rank,
            "singular_values": s,
            "optimal_loss": best,
            "suggested_mu": suggested_mu
        }
        print(f"for this layer, selected rank is {selected_rank}, "
              f"normalized ‖w‖²={(s ** 2).sum() / norm_sq:.3f}, "
              f"true ‖w‖²={(s ** 2).sum():.3f}, "
              f"‖Δ(Θ)‖²={(low_rank_matrix ** 2).sum() / norm_sq:.3f}, "
              f"‖w-Δ(Θ)‖²={frob_norm_diff:.3e}, "
              f"μ should be at least {suggested_mu:.2e}, "
              f"this is SVD_compression")
        self.info[self.step_number] = step_info
        self._state = {"U": U, "V": V,"S": S, "selected_rank": selected_rank, "optimal_loss": best, "init_shape": init_shape}

        if len(init_shape) == 2:
            return low_rank_matrix
        elif len(init_shape) == 4:
            return matrix_to_tensor(low_rank_matrix, init_shape, self.conv_scheme)

    def loss_svd(self):
        return self._state['optimal_loss']

    def cost_return(self):
        return self.Cost_all

class LowRank_FM(CompressionTypeBase):
    def __init__(self, target_rank, conv_scheme=None, precision='float'):
        """
        The low-rank compression of the matrix into given low-rank. If tensor is given, then it should be reshaped into
        a matrix according to a conv_scheme: either of scheme_1 or scheme_2.

        :param target_rank: the target rank of compressed weights
        :param conv_scheme: if tensor is given, how it should be reshaped into matrix
        :param precision: should be store low-rank U,V with different precision (32 or 16 bits)
        """
        #         print("are we here?")
        super(LowRank_FM, self).__init__()
        self.target_rank = target_rank
        self.conv_scheme = conv_scheme
        self.precision = (32 if precision == 'float' else precision)

    def perform_svd(self, matrix):
        u, s, v = svd(matrix, full_matrices=False)
        return u, s, v

    def compress(self, data):
        print("we are here")
        matrix = None
        init_shape = data.shape
        if data.ndim == 2:
            matrix = data
        elif data.ndim == 4:
            matrix = tensor_to_matrix(data, self.conv_scheme)

        u, s, v = self.perform_svd(matrix)
        r = self.target_rank
        print("target_rank", self.target_rank)
        if r < np.min(matrix.shape):
            diag = np.diag(s[:r] ** 0.5)
            U = u[:, :r] @ diag
            V = diag @ v[:r, :]

            if self.precision == 16:
                print("Storing U,V matrices as 16bit IEEE floating point matrices.")
                U = U.astype(np.float16)
                V = V.astype(np.float16)

            low_rank_matrix = U @ V
            self.info[self.step_number] = [U, V]

            step_info = {"selected_rank": None, "singular_values": s}
            self.info[self.step_number] = step_info
            self._state = {"U": U, "V": V, "selected_rank": None, "init_shape": init_shape}

            print("Low-rank compression is finished")
            if len(init_shape) == 2:
                return low_rank_matrix
            elif len(init_shape) == 4:
                return matrix_to_tensor(low_rank_matrix, init_shape, self.conv_scheme)

    def load_state_dict(self, state_dict):
        self._state = state_dict

    def uncompress_state(self):
        U = self.state_dict['U']
        V = self.state_dict['V']
        if len(self.state_dict["init_shape"]) == 2:
            return U @ V
        elif len(self.state_dict["init_shape"]) == 4:
            return matrix_to_tensor(U @ V, self.state_dict["init_shape"], self.conv_scheme)

    def count_params(self):
        if "U" in self._state:
            return self._state['U'].size + self._state['V'].size
        else:
            raise Error("Cannot count the number of compressed params: no compression was performed")

    def count_param_bits(self):
        if "U" in self._state:
            return (self._state['U'].size + self._state['V'].size) * 32
        else:
            raise Error("Cannot count the number of compressed params: no compression was performed")


class RankSelection_FM(LowRank_FM):
    def __init__(self, conv_scheme, alpha, criterion, normalize, module):

        super(RankSelection_FM, self).__init__(None, conv_scheme)
        self.alpha = alpha
        self.module = module
        self.criterion = criterion
        self.selected_rank = 0
        self.normalize_matrix = normalize
        self.sigma = 1
        self.Cost_all = 0
        self.num_comp = 0

    def compress(self, data):
        matrix = None
        init_shape = data.shape
        if data.ndim == 2:
            matrix = data
        elif data.ndim == 4:
            matrix = tensor_to_matrix(data, self.conv_scheme)

        u, s, v = self.perform_svd(matrix)
        m, n = matrix.shape
        self.matrix_num = m * n
        num_com = 0
        min_r = min(matrix.shape)
        max_rank = int((m * n)/(m + n))
        selected_rank = 0
        best = float('Inf')     # ∞
        # rank_i_diff_frb_norm_sq = (s[::-1] ** 2).cumsum()[::-1]  # 值从小加到大(-1 -> 0)，计算各级r的奇异值σ的平方和：s[0]为所有奇异值Σσ^2之和
        # rank_i_frb_norm_sq = (s[:] ** 2).cumsum()  # 值从大加到小(0 -> -1)，这里计算的是各级r的奇异值σ的平方和：s[-1]为所有奇异值Σσ^2之和

        norm_sq = 1.0
        mult = 1 if self.criterion == 'storage' else self.module.multiplier

        def cost(r):
            return r*(m+n)*mult

        # 修改部分
        cost_l = float('inf')
        epoch = 1000
        U_true = None
        V_true = None
        # print(self.conv_scheme)
        print(matrix.shape)

        diag = np.diag(s[:max_rank] ** 0.5)
        U_ = u[:, :max_rank]
        V_ = v[:max_rank, :]
        U = np.matmul(U_, diag)
        V = np.matmul(diag, V_)
        U = np.random.rand(m, max_rank) * 1e-3
        V = np.random.rand(max_rank, n) * 1e-3
        if max_rank > 200:
            max_rank = int(max_rank / 15)
        elif max_rank <= 200 and max_rank > 100:
            max_rank = int(max_rank / 5)
        print("!!!!!!sign x!!!!!!!!!!!!!")
        for r in range(0, max_rank + 1):
            loss_1 = float('inf')
            Cost = float('inf')
            learning_rate = 0.1 # 0.11
            a_lambda = 0.1 # 0.99
            b_lambda = 0.1 # 0.99
            rank = max_rank - r
            if r != 0:
                # U = np.random.rand(m, rank) * 1e-3
                # V = np.random.rand(rank, n) * 1e-3
                diag = np.diag(s[:rank] ** 0.5)
                U_ = u[:, :rank]
                V_ = v[:rank, :]
                U = np.matmul(U_, diag)
                V = np.matmul(diag, V_)
            # print("矩阵rank秩为:{}, 参数数目为:{}, 压缩率为:{}".format(rank, rank * (m + n), (rank * (m + n)) / (m * n)))

            for i in range(epoch):
                if i % 100 == 0:
                    learning_rate *= 0.1
                    a_lambda *= 0.1
                    b_lambda *= 0.1

                loss_l = self.mu * (matrix - np.matmul(U, V))
                grad_u = np.matmul(loss_l, V.T) - 2 * a_lambda * U
                grad_v = np.matmul(U.T, loss_l) - 2 * a_lambda * V
                U = U + learning_rate * grad_u
                V = V + learning_rate * grad_v

                # cnt_1 = U @ V  # np.matmul(U, V.T)
                # cnt_2 = U.T @ U  # np.matmul(V, U.T)
                # grad_1 = self.mu * (cnt_1 @ V.T - matrix @ V.T + a_lambda * U)
                # grad_2 = self.mu * (cnt_2 @ V - U.T @ matrix + b_lambda * V)
                # U = U - learning_rate * grad_1
                # V = V - learning_rate * grad_2
                new_X = np.matmul(U, V)
                # print(loss)
                err_matrix = (self.mu / 2) * np.sum((matrix - new_X) ** 2)
                store = self.alpha * cost(rank) * 1e-1
                Cost = err_matrix + store
                num_com = cost(rank)
                cost_all = self.sigma * (cost(rank) / self.matrix_num) + err_matrix * 0 # * (1 / self.alpha)
                if (i + 1) % 100 == 0:
                    # print("秩更新为:{}，第{}轮均方loss为:{:f},矩阵误差err为:{:f},存储空间store为:{:f}".format(rank, i + 1, Cost, err_matrix,
                    #                                                                        store))
                    if abs(loss_1 - Cost) < 1e-4:
                        # print("Cost: ", Cost)
                        # print("loss_1: ", loss_1)
                        break
                    loss_1 = Cost
                if Cost < 1e-4:
                    break

            # print("!!!!!!sign:{}!!!!!!!!!!!!!,error:{}".format(rank, Cost))
            if rank == 0:
                print(U)
                print(V)

            if Cost < cost_l:
                cost_l = Cost
                U_true = U
                V_true = V
                selected_rank = rank
                self.Cost_all = cost_all
                self.num_comp = num_com

            # print("此时的矩阵形状:{},秩为:{},代价cost为:{}".format(data.shape, rank, cost_l))

        low_rank_matrix = np.matmul(U_true, V_true)

        rank_i_diff_frb_norm_sq = (s[::-1] ** 2).cumsum()[::-1]
        rank_i_frb_norm_sq = (s[:] ** 2).cumsum()

        if self.normalize_matrix:
            frob_norm_sq = rank_i_diff_frb_norm_sq[0]
            norm_sq = frob_norm_sq

        suggested_mu = 2 * self.alpha * (m + n) * mult / (s[0] ** 2 / norm_sq)

        if selected_rank <= max_rank:
            frob_norm_diff = (self.mu / 2) * np.sum((matrix - low_rank_matrix) ** 2)
            # (rank_i_diff_frb_norm_sq[selected_rank]/norm_sq if selected_rank < max_rank else 0)
        else:
            frob_norm_diff = 0

        self.selected_rank = selected_rank
        step_info = {
            "selected_rank": selected_rank,
            "singular_values": s,
            "optimal_loss": cost_l,  # best
            "suggested_mu": suggested_mu
        }
        print(f"for this layer, selected rank is {selected_rank}, "
              f"normalized ‖w‖²={(s ** 2).sum() / norm_sq:.3f}, "
              f"true ‖w‖²={(s ** 2).sum():.3f}, "
              f"‖Δ(Θ)‖²={(low_rank_matrix ** 2).sum() / norm_sq:.3f}, "
              f"‖w-Δ(Θ)‖²={frob_norm_diff:.3e}, "
              f"μ should be at least {suggested_mu:.2e},"
              f"this is FM_compression")
        self.info[self.step_number] = step_info
        self._state = {"U": U_true, "V": V_true.T, "selected_rank": selected_rank, "optimal_loss": cost_l, "init_shape": init_shape}

        if len(init_shape) == 2:
            return low_rank_matrix
        elif len(init_shape) == 4:
            return matrix_to_tensor(low_rank_matrix, init_shape, self.conv_scheme)

    def loss_mf(self):
        return self._state['optimal_loss']

    def cost_return(self):
        return self.Cost_all
